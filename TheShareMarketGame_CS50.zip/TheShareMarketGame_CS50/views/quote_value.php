<p>A share of <?= htmlspecialchars($values["name"]) ?> (<?= htmlspecialchars($values["symbol"]) ?>) costs $<?= htmlspecialchars($values["price"]) ?></p>
