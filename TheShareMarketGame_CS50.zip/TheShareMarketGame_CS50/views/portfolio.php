<div>
    <table style="width: 100%; border: 1px solid black">
        <colgroup>
            <col style="width: 20%;">
            <col style="width: 20%;">
            <col style="width: 20%;">
            <col style="width: 20%;">
            <col style="width: 20%;">
        </colgroup>
        <tr>
            <td><b>Symbol</b></td>
            <td><b>Name</b></td>
            <td><b>Shares</b></td>
            <td><b>Price</b></td>
            <td><b>TOTAL</b></td>
        </tr>

        <?php
            $dollar = "$";
            foreach ($positions as $position)
            {
                $total = $position["shares"] * $position["price"];
                $total = number_format($total, 2, '.', '');
                print("<tr>");
                print("<td>{$position["symbol"]}</td>");
                print("<td>{$position["name"]}</td>");
                print("<td>{$position["shares"]}</td>");
                print("<td>{$dollar}{$position["price"]}</td>");
                print("<td>{$dollar}{$total}</td>");
                print("</tr>");
            }
            foreach ($positions1 as $position)
            {
                print("<tr>");
                print("<td><b>CASH</b></td>");
                print("<td></td>");
                print("<td></td>");
                print("<td></td>");
                print("<td>{$dollar}{$position["cash"]}</td>");
                print("</tr>");
                break;
            }
        ?>
    </table>
</div>
