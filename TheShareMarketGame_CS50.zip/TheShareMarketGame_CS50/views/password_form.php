<form action="password.php" method="post">
    <fieldset>
        <div class="form-group">
            <input autocomplete="off" autofocus class="form-control" name="password" placeholder="New Password" type="password"/>
        </div>
        <div class="form-group">
            <input autocomplete="off" autofocus class="form-control" name="password1" placeholder="Confirmation" type="password"/>
        </div>
        <div class="form-group">
            <button class="btn btn-default" type="submit">
                CHANGE
            </button>
        </div>
    </fieldset>
</form>
