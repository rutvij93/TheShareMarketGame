<div>
    <table style="width: 100%; border: 1px solid black">
        <colgroup>
            <col style="width: 20%;">
            <col style="width: 20%;">
            <col style="width: 20%;">
            <col style="width: 20%;">
            <col style="width: 20%;">
        </colgroup>
        <tr>
            <td><b>Transaction</b></td>
            <td><b>Date/Time</b></td>
            <td><b>Symbol</b></td>
            <td><b>Shares</b></td>
            <td><b>Price</b></td>
        </tr>

        <?php
            $dollar = "$";
            foreach ($positions as $position)
            {
                print("<tr>");
                print("<td>{$position["transaction"]}</td>");
                print("<td>{$position["date/time"]}</td>");
                print("<td>{$position["symbol"]}</td>");
                print("<td>{$position["shares"]}</td>");
                print("<td>{$dollar}{$position["price"]}</td>");
                print("</tr>");
            }
        ?>
    </table>
</div>
