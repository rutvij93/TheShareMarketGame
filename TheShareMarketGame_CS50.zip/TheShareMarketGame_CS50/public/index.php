<?php
    // configuration
    require("../includes/config.php");
    $rows = CS50::query("SELECT * FROM portfolio WHERE user_id = ?", $_SESSION["id"]);
    $rows1 = CS50::query("SELECT cash FROM users WHERE id = ?", $_SESSION["id"]);
    $positions = [];
    $positions1 = [];

    foreach ($rows as $row)
    {
        $stock = lookup($row["symbol"]);
        if ($stock !== false)
        {
            $stock["price"] = number_format($stock["price"], 2, '.', '');
            $positions[] = [
                "name" => $stock["name"],
                "price" => $stock["price"],
                "shares" => $row["shares"],
                "symbol" => $row["symbol"],
            ];
        }
    }
    foreach ($rows1 as $row)
    {
        $row["cash"] = number_format($row["cash"], 2, '.', '');
        $positions1[] = ["cash" => $row["cash"]];
    }
    
    // render portfolio
    $page = $_SERVER['PHP_SELF'];
    $sec = "300";
    header("Refresh: $sec; url=$page");
    render("portfolio.php", ["positions" => $positions, "title" => "Portfolio", "positions1" => $positions1]);
?>
