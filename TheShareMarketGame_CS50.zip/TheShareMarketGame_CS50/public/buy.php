<?php
    // configuration
    require("../includes/config.php");
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        // else render form
        render("buy_form.php", ["title" => "BUY STOCK"]);
    }
    else if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        $stock = lookup($_POST["symbol"]);
        $_POST["symbol"] = strtoupper($_POST["symbol"]);
        $rows = CS50::query("SELECT * FROM portfolio WHERE user_id = ? AND symbol = ?", $_SESSION["id"], $_POST["symbol"]);
        if(!(isset($stock["price"])))
        {
            apologize("You must provide valid stock symbol.");
        }
        else if(!(preg_match("/^\d+$/", $_POST["shares"])))
        {
            apologize("You can not buy shares in fractions.");
        }
        else if(empty($rows))
        {
            $stock = lookup($_POST["symbol"]);
            $rows = CS50::query("SELECT cash FROM users WHERE id = ?", $_SESSION["id"]);
            if($rows[0]["cash"] >= ($stock["price"] * $_POST["shares"]))
            {
                CS50::query("INSERT INTO portfolio (user_id, symbol, shares) VALUES(?, ?, ?)", $_SESSION["id"], $_POST["symbol"], $_POST["shares"]);
                CS50::query("UPDATE users SET cash = cash - (? * ?) WHERE id = ?", $stock["price"], $_POST["shares"], $_SESSION["id"]);
                CS50::query("INSERT INTO history (id, transaction, symbol, shares, price) VALUES (?, ?, ?, ?, ?)", $_SESSION["id"], "BUY", $_POST["symbol"], $_POST["shares"], number_format(($_POST["shares"] * $stock["price"]), 2, '.', '')); 
                render("buy_form.php", ["title" => "BUY STOCK"]);
            }
            else
            {
                apologize("You can not afford this stock.");
            }
        }
        else
        {
            $stock = lookup($_POST["symbol"]);
            $rows = CS50::query("SELECT cash FROM users WHERE id = ?", $_SESSION["id"]);
            if($rows[0]["cash"] >= ($stock["price"] * $_POST["shares"]))
            {
                CS50::query("UPDATE portfolio SET shares = shares + ? WHERE user_id = ? AND symbol = ?", $_POST["shares"], $_SESSION["id"], $_POST["symbol"]);
                CS50::query("UPDATE users SET cash = cash - (? * ?) WHERE id = ?", $stock["price"], $_POST["shares"], $_SESSION["id"]);
                CS50::query("INSERT INTO history (id, transaction, symbol, shares, price) VALUES (?, ?, ?, ?, ?)", $_SESSION["id"], "BUY", $_POST["symbol"], $_POST["shares"], number_format(($_POST["shares"] * $stock["price"]), 2, '.', '')); 
                render("buy_form.php", ["title" => "BUY STOCK"]);
            }
            else
            {
                apologize("You can not afford this stock.");
            }
        }
    }
    
    
?>