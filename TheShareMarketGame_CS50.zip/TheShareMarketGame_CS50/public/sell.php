<?php
    // configuration
    require("../includes/config.php");
    if ($_SERVER["REQUEST_METHOD"] == "GET")
    {
        // else render form
        render("sell_form.php", ["title" => "SELL STOCK"]);
    }
    else if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
        $_POST["symbol"] = strtoupper($_POST["symbol"]);
        $stock = lookup($_POST["symbol"]);
        $rows = CS50::query("SELECT * FROM portfolio WHERE user_id = ? AND symbol = ?", $_SESSION["id"], $_POST["symbol"]);
        if(!(isset($stock["price"])))
        {
            apologize("You must provide valid stock symbol.");
        }
        elseif(empty($rows))
        {
            apologize("You dont have that stock.");
            break;
        }
        else
        {
            foreach ($rows as $row)
            {
                CS50::query("UPDATE users SET cash = cash + (? * ?) WHERE id = ?", $stock["price"], $row["shares"], $_SESSION["id"]);
                CS50::query("INSERT INTO history (id, transaction, symbol, shares, price) VALUES (?, ?, ?, ?, ?)", $_SESSION["id"], "SELL", $_POST["symbol"], $row["shares"], number_format(($row["shares"] * $stock["price"]), 2, '.', ''));
            }
            CS50::query("DELETE FROM portfolio WHERE user_id = ? AND symbol = ?", $_SESSION["id"], $_POST["symbol"]);
            render("sell_form.php", ["title" => "SELL STOCK"]);
        }
    }
    
    
?>