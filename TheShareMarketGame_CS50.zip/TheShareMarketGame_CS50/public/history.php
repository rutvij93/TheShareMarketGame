<?php
    // configuration
    require("../includes/config.php");
    $rows = CS50::query("SELECT * FROM history WHERE id = ? ORDER BY `date/time` DESC", $_SESSION["id"]);
    $positions = [];

    foreach ($rows as $row)
    {
        $positions[] = [
            "transaction" => $row["transaction"],
            "date/time" => $row["date/time"],
            "shares" => $row["shares"],
            "symbol" => $row["symbol"],
            "price" => $row["price"]
        ];
    }
    // render portfolio
    render("history_display.php", ["positions" => $positions, "title" => "Portfolio"]);
?>
